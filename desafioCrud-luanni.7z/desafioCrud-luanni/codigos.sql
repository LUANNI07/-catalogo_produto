 USE catalogo_produtos ;

--criador do banco de dados 
 CREATE DATABASE catalogo_produtos

 -- criar tabela 
CREATE TABLE produtos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(225) NOT NULL,
  descricao TEXT,
  preco DECIMAL(10,2) NOT NULL
);
 
 -- fizemaos os endpoints

 -- rodamos o node server.js no terminal
 -- adicionamos os produtos

   {
    "nome": "Laptop Gamer",
    "descricao": "Laptop com processador Intel Core i7 e placa de vídeo NVIDIA GeForce",
    "preco": 2999.90
  }

    {
    "nome": "Câmera Digital",
    "descricao": "Câmera digital com sensor de 24MP e zoom óptico de 10x",
    "preco": 1499.90
  }

    {
    "nome": "Telefone Inteligente",
    "descricao": "Telefone com tela de 6 polegadas e câmera de 12MP",
    "preco": 999.90
  },

   -- atualizamos os produtos com um valor diferente

  {
    "nome": "Laptop Gamer",
    "descricao": "Laptop com processador Intel Core i7 e placa de vídeo NVIDIA GeForce",
    "preco": 3000.00
  }

      {
    "nome": "Telefone Inteligente",
    "descricao": "Telefone com tela de 6 polegadas e câmera de 12MP",
    "preco": 1000.00
  }

     {
    "nome": "Câmera Digital",
    "descricao": "Câmera digital com sensor de 24MP e zoom óptico de 10x",
    "preco": 1500.00
  }
